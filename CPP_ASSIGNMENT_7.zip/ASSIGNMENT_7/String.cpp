
/*
Design (define what all constructors, member functions and operator functions to overload relational operators) and implement them.
   Also write a small program to demonstrate the use of String class and overloaded relational operators.
*/
#include<iostream>
#include<cstring>
using namespace std;

class String{
	private:
		char *str;
		int size;
	public :
		String():size(6){	
            str = new char[size];
			str[0] = '\0';
		}
		String(char *string){   
            size = strlen(str);
			str = new char[size + 1];
			strcpy(str, string);
		}
        String(String &obj){ 
            cout<<"Copy Constructor Called"<<endl;
            size = obj.size;
			str = new char[size];
			strcpy(str, obj.str);
		}	
		void display(){   
            for(int i = 0; str[i] != '\0'; i++){
				cout<<str[i];
			}
			cout<<endl;
		}
        bool operator==(String &obj2){
            for( int i = 0; (str[i] != '\0')||(obj2.str[i] !='\0'); i++){
                if(str[i] != obj2.str[i])
                    return false;
            }      
            return false;
        }
        bool operator!=(String &obj2){
            if(*this == obj2)
                return false;
            return true;
        }
        bool operator>(String &obj2){
            for( int i = 0; (str[i] != '\0')||(obj2.str[i] !='\0'); i++){
                if(str[i] <= obj2.str[i])
                    return false;
            }      
            return true;
        }
        bool operator>=(String &obj2){
            if(*this > obj2 || *this == obj2)
                return true;
            return false;
        }
        bool operator<=(String &obj2){
            if(*this < obj2 || *this == obj2)
                return true;
            return false;
        }
        bool operator<(String &obj2){
            for( int i = 0; (str[i] != '\0')||(obj2.str[i] !='\0'); i++){
                if(str[i] >= obj2.str[i])
                    return false;
            }      
            return true;
        }
        ~String(){
    		cout<<"memory is freed "<<endl;
			delete[] str;
		}
};
int main(){
	String obj1("abc"), obj2("xyz" );
    obj1.display();
    obj2.display();

    if(obj1 == obj2)
        cout<<"Both strings are equal"<<endl;
    else 
        cout<<"Both strings are not equal"<<endl;

    if(obj1 >= obj2)
        cout<<"First string is greater than second"<<endl;
    else 
        cout<<"First string is less than second"<<endl;

    String obj3("krupa"), obj4(obj3);
    if(obj3 < obj4) //obj3.operator<(obj4)
        cout<<"First string is less than second"<<endl;
    else 
        cout<<"First string is greater than second"<<endl;
    return 0;
}
