/*1. Finish the implementation of BigInt class by overloading remaining relational operators to compare two BigInt objects.
   Also write a small program to demonstrate the use of BigInt class and overloaded relational operators.*/
#include<iostream>
using namespace std;
class BigInt{
    int num;
    public: 
        BigInt():num(0){
        }
        BigInt(int num): num(num){
        }
        void display() const{
            cout << num << endl;
        }
        void set(){
            cout << "Enter number: ";
            cin >> num;
        }
        bool operator== (BigInt b){
            if(b.num == this->num)
                return true;
            return false;
        }
        
        bool operator<= (BigInt b){
            if(this->num <= b.num)
                return true;
            return false;
        }
        bool operator> (BigInt b){
            if(*this <= b)
                return false;
            return true;
        }
        bool operator>= (BigInt b){
            if(this->num >= b.num)
                return true;
            return false;
        }
        bool operator < (BigInt b){
            if(*this >= b)
                return false;
            return true;
        }
        bool operator!= (BigInt b){
            if(*this == b)
                return false;
            return true;
        }
};

int main(){
    BigInt b1, b2(2), b3(3);
    b1.set();
    b1.display();
    b2.display();
    b3.display();
    if(b2 == b3)
        cout << "b2 and b3 are Equal"<<endl;
    else
        cout << "b2 and b3 are not equal"<<endl;
    
    if(b2 < b3)
        cout << "b2 is less than b3 "<<endl;
    else
        cout << "b2 is greater than b3"<<endl;
    
    if(b1 >= b3)
        cout << "b1 is greater than or equal b3"<<endl;
    else
        cout << "b1 is less than  b3"<<endl;
    return 0;
}