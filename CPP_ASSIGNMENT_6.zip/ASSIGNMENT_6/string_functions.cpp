#include<iostream>
using namespace std;

int stringLen(char str[]);
void stringCopy(char dest[], char src[]);
bool stringCmp(char str1[], char str2[]);
void toLower(char str[]);
void toUpper(char str[]);
int main(){
    int l = 0, choice; 
    char str1[20], str2[20];
    do{
        cout<<"1. Length of string\n2. Copy string\n3. Compare strings\n4. convert to upper\n5. convert to lower\n6. Exit"<<endl;
        cout<<"Enter your choice: ";
        cin>>choice;
        switch(choice){
            case 1:
                fflush(stdin);
                cout<<"Enter string: ";
                cin.getline(str1, 20); 
                cout<<"Length of string: "<<stringLen(str1);
                break;
            case 2:
                fflush(stdin);
                cout<<"Enter string: ";
                cin.getline(str1, 20);
                stringCopy(str2, str1);
                cout<<"String2: "<<str2;
                break;
            case 3:
                fflush(stdin);
                cout<<"Enter string1: ";
                cin.getline(str1, 20);
                cout<<"Enter string2: ";
                cin.getline(str2, 20);
                if(stringCmp(str1, str2))
                    cout<<"Equal"<<endl;
                else   
                    cout<<"Not Equal"<<endl;
                break;
            case 4:
                fflush(stdin);
                cout<<"Enter string: ";
                cin.getline(str1, 20);
                toUpper(str1);
                cout<<"String in uppercase: "<<str1<<endl;
                break;
            case 5:
                fflush(stdin);
                cout<<"Enter string: ";
                cin.getline(str1, 20);
                toLower(str1);
                cout<<"String in lowercase: "<<str1<<endl;
                break;
            case 6:
                exit(0);
        }
        cout<<"Enter 0 to exit..";
        cin>>choice;
    }while(choice != 0);

    return 0;
}
int stringLen(char str[]){
    int i;
    for(i = 0; str[i] != '\0'; i++);
    return i;
}
void stringCopy(char dest[], char src[]){
    int i;
    for(i = 0; src[i] != '\0'; i++){
        *(dest+i) = *(src+i);
    }
}
bool stringCmp(char str1[], char str2[]){
    int i, j;
    for(i = 0, j = 0; str1[i] != '\0' || str2[i] != '\0'; i++, j++){
        if(*(str1+i) != *(str2+j))
            return false;
    }
    return true;
}

void toLower(char str[]){
    for(int i = 0 ; str[i] != '\0' ; i++){
        if(*(str+i) >= 'A' && *(str+i) <= 'Z')
            *(str+i) += 32;
    }
}
void toUpper(char str[]){
    for(int i = 0 ; str[i] != '\0' ; i++){
        if(*(str+i) >= 'a' && *(str+i) <= 'z')
            *(str+i) -= 32;
    }
}
