#include<iostream>
using namespace std;

void swap_val(int , int );
void swap_add(int *, int *);

int main(){
    int a, b;
    cout<<"Enter two numberes: ";
    cin>>a>>b;
    
    cout<<"========Call By Value========"<<endl;
    cout<<"Before Swapping"<<endl;
    cout<<"a = "<<a<<"\tb = "<<b<<endl;
    swap_val(a, b);
    cout<<"After Swapping"<<endl;
    cout<<"a = "<<a<<"\tb = "<<b<<endl;
    
    cout<<"========Call By Address========"<<endl;
    cout<<"Before Swapping"<<endl;
    cout<<"a = "<<a<<"\tb = "<<b<<endl;
    swap_add(&a, &b);
    cout<<"After Swapping"<<endl;
    cout<<"a = "<<a<<"\tb = "<<b<<endl;
    return 0;
}

void swap_val(int x, int y){
    int t = x;
    x = y;
    y = t;
}

void swap_add(int *x, int *y){
    int t = *x;
    *x = *y;
    *y = t;
}