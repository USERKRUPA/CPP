#include<iostream>
using namespace std;

void swap_ref(int &, int &);
int main(){
    int a, b;
    cout<<"Enter two numberes: ";
    cin>>a>>b;
    
    cout<<"========Call By Reference========"<<endl;
    cout<<"Before Swapping"<<endl;
    cout<<"a = "<<a<<"\tb = "<<b<<endl;
    swap_ref(a, b);
    cout<<"After Swapping"<<endl;
    cout<<"a = "<<a<<"\tb = "<<b<<endl;

    return 0;
}

void swap_ref(int &x, int &y){
    int t = x;
    x = y;
    y = t;
}