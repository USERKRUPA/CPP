#include<iostream>
using namespace std;
void swap_val(int& , int&);
void swap_val(float& , float&);
void swap_val(double& , double&);
void swap_val(char& , char&);

int main(){
    int no1, no2;
    float fno1, fno2;
    double dno1, dno2;
    char cno1, cno2;
    int choice;
    do{
        cout<<"1 Swap Integer Data\n2 Swap Float Data\n3 Swap Double Data\n4 Swap Character Data\n5 Exit"<<endl;
        cout<<"Enter your choice: ";
        cin>>choice;
        switch(choice){
            case 1:
                    cout<<"Enter no1(integer): "<<endl;
                    cin>>no1;
                    cout<<"Enter no2(integer): "<<endl;
                    cin>>no2;
                    cout<<"Swapping of integer: "<<endl;
                    cout<<"no1= "<<no1<<"\tno2= "<<no2<<endl;
                    swap_val(no1, no2);
                    cout<<"no1= "<<no1<<"\tno2= "<<no2<<endl;
                    break;
            case 2:
                    cout<<"Enter no1(float): "<<endl;
                    cin>>fno1;
                    cout<<"Enter no2(float): "<<endl;
                    cin>>fno2;
                    cout<<"Swapping of float data: "<<endl;
                    cout<<"fno1= "<<fno1<<"\tfno2= "<<fno2<<endl;
                    swap_val(fno1, fno2);
                    cout<<"fno1= "<<fno1<<"\tfno2= "<<fno2<<endl;
                    break;
            case 3:
                    cout<<"Enter no1(double): "<<endl;
                    cin>>dno1;
                    cout<<"Enter no2(double): "<<endl;
                    cin>>dno2;
                    cout<<"Swapping of double data: "<<endl;
                    cout<<"dno1= "<<dno1<<"\tdno2= "<<dno2<<endl;
                    swap_val(dno1, dno2);
                    cout<<"dno1= "<<dno1<<"\tdno2= "<<dno2<<endl;
                    break;
            case 4:
                    cout<<"Enter any character: "<<endl;
                    cin>>cno1;
                    cout<<"Enter another character: "<<endl;
                    cin>>cno2;
                    cout<<"Swapping of character data: "<<endl;
                    cout<<"cno1= "<<cno1<<"\tcno2= "<<cno2<<endl;
                    swap_val(cno1, cno2);
                    cout<<"cno1= "<<cno1<<"\tcno2= "<<cno2<<endl;
                    break;
            case 5:
                    exit(0);
            default:
                    cout<<"Enter valid input"<<endl;
        }
        cout<<"Enter 0 to exit"<<endl;
        cin>>choice;
    }while(choice);
    return 0;
}

void swap_val(int &n1, int &n2){
    int tmp;
    tmp = n1;
    n1 = n2;
    n2= tmp;
}

void swap_val(float &n1, float &n2){
    float tmp;
    tmp = n1;
    n1 = n2;
    n2= tmp;
}

void swap_val(double &n1, double &n2){
    double tmp;
    tmp = n1;
    n1 = n2;
    n2= tmp;
}

void swap_val(char &n1, char &n2){
    char tmp;
    tmp = n1;
    n1 = n2;
    n2= tmp;
}