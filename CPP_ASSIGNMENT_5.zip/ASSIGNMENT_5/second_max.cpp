#include<iostream>
using namespace std;

int findSecondLargest(int nums[], int n);

int main(){
    int size;
    do{
        cout<<"enter size in positive: "<<endl;
        cin>>size; 
    }while(size < 0);

    int a[size], i, smax;
    cout<<"Enter elements of an array:"<<endl;
    for(i = 0; i < size; i++){
        cin>>a[i];
    }  
    smax = findSecondLargest(a, size);
    
    cout<<"second maximum is: "<<smax<<endl;
   
    return 0;
}

int findSecondLargest(int nums[], int n){
    int max = 0, smax = 0, i;
    for(i = 0; i < n; i++){
        if(nums[i] > max){
            smax = max;
            max = nums[i];
        }
        else if(nums[i] > smax){
            smax = nums[i];
        }
    }
    if (nums[0] == max){
        for(i = 1; i < n; i++){
            if(smax <= nums[i]){
                smax = nums[i];
            }
        }
    }
    return smax;
}
