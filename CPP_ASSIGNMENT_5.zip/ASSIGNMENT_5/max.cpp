#include<iostream>
using namespace std;
int findMax(int nums[], int n){
    int max, i;
    max = nums[0];
    for(i = 1; i < n; i++){
        if(nums[i] > max)
            max = nums[i];
    }
    return max;
} 

void printArray(int *arr, int n){
    
    for(int i = 0; i < n; i++){
        cout<<"arr["<<i<<"]: "<<*(arr+i)<<endl;
    }
}

int main(){
    int i, n;
    cout<<"Enter size of an array: ";
    cin>>n;
    int arr[n];
    cout<<"Enter "<<n<<" elements of an array: "<<endl;
    for(i = 0; i < n; i++){
        cout<<"arr["<<i<<"]: ";
        cin>>arr[i];
    }
    cout<<"minimum no is: "<<findMax(arr,n)<<endl;
    return 0;
}