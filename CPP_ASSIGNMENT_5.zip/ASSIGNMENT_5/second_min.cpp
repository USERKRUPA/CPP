#include<iostream>
using namespace std;

int findSecondSmallest(int nums[], int n);

int main(){
    int size;
    do{
        cout<<"enter size in positive: "<<endl;
        cin>>size; 
    }while(size < 0);

    int a[size], i, smin;
    cout<<"Enter elements of an array:"<<endl;
    for(i = 0; i < size; i++){
        cin>>a[i];
    }  
  
    smin = findSecondSmallest(a, size);
    cout<<"second minimum is: "<<smin<<endl;
    return 0;
}

int findSecondSmallest(int nums[], int n){
    int min , smin , i;
    for(i = 0; i < n; i++){
        if(nums[i] < min){
            smin = min;
            min = nums[i];
        }
        else if(nums[i] < smin){
            smin = nums[i];
        }
    }
    if (nums[0] == min){
        for(i = 1; i < n; i++){
            if(smin <= nums[i]){
                smin = nums[i];
            }
        }
    }
    return smin;
}