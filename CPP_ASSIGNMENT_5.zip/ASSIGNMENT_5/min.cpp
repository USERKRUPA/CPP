#include<iostream>
using namespace std;

int findMin(int nums[], int n){
    int min,i;
    min = nums[0];
    for(i = 1; i < n ; i++){
        if(nums[i]<min){
            min = nums[i];
        }
    }
    return min;
}

void printArray(int *arr, int n){
    
    for(int i = 0; i < n; i++){
        cout<<"arr["<<i<<"]: "<<*(arr+i)<<endl;
    }
}

int main(){
    int i, n;
    cout<<"Enter size of an array: ";
    cin>>n;
    int arr[n];
    cout<<"Enter "<<n<<" elements of an array: "<<endl;
    for(i = 0; i < n; i++){
        cout<<"arr["<<i<<"]: ";
        cin>>arr[i];
    }   
    cout<<"minimum no is: "<<findMin(arr,n)<<endl;
    return 0;
}