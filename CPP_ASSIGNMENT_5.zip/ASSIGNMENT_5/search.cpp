#include<iostream>
using namespace std;

bool search(int nums[], int n, int element);

int main(){
    int size;
    do{
        cout<<"enter size in positive: "<<endl;
        cin>>size; 
    }while(size < 0);

    int a[size], i, find;
    cout<<"Enter elements of an array:"<<endl;
    for(i = 0; i < size; i++){
        cin>>a[i];
    }  
    cout<<"Enter element you want to search: "<<endl;
    cin>>find;
    if(search(a, size, find))
        cout<<find<<" is found."<<endl;
    else
        cout<<find<<" is not found."<<endl;
}

bool search(int nums[], int n, int element){
    for(int i = 0; i < n; i++){
        if(nums[i] == element){
            return true;
        }
    }
    return false;
}