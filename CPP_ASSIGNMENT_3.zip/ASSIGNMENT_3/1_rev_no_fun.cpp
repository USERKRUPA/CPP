#include <iostream>
using namespace std;
int reverse(int);
int main(void) {
    int no;
    do{
        cout<<"enter a positive number: ";
        cin>>no;
    }while(no < 0);
    cout<<"Reverse of "<<no<<" is: "<<reverse(no);
    return 0;
}
int reverse(int num){
    int rem, rev = 0;
    while(num != 0){
        rem = num % 10;
        rev =  (rev * 10)  + rem; 
        num = num / 10;
    }
    return rev;
}
