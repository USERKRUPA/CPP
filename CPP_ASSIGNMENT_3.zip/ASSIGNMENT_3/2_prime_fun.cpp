#include<iostream>
using namespace std;

bool isprime(int num){
    int i;
    for(i = 2; i < num; i++){
        if(num % i == 0){
            break;
        }
    }
    if(i == num)
        return true;
    return false;
}

int main(void){
    int strt, end, no, i;
    do{
        cout<<"Enter starting positive no: ";
        cin>>strt;
    }while(strt < 0);
    do{
        cout<<"Enter last positive no: ";
        cin>>end;
    }while(end < 0);
    
    for(no = strt; no <= end; no++){
        if(isprime(no))
            cout << no <<", ";
    }
    return 0;
}