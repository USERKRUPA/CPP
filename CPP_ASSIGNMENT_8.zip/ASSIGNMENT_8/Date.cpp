/*
 For the Date class overload following operators.
   Binary operator + to work with
   - one Date operand and one int
   Binary operator - to work with
   - both operands of type Date
   - one Date operand and one int
   Unary operators ++ and -- in both pre and post form.
   Also write a small program to demonstrate the use of Date class and overloaded relational operators.
*/
#include<iostream>
using namespace std;

class Date{
    int day;
    int month;
    int year;

    public:
        Date():day(1), month(1), year(23){
        }
        Date(int d, int m, int y): day(d), month(m), year(y){
        }
        Date(Date &dt){
            this->day = dt.day;
            this->month = dt.month;
            this->year = dt.year;
        }
        void Read(){
            cout<<"Enter Day: ";
            cin>>day;
            cout<<"\nEnter Month: ";
            cin>>month;
            cout<<"\nEnter year: ";
            cin>>year;
        }
        void Write(){
            cout<<"Date: ";
            cout<<day<<"-"<<month<<"-"<<year<<endl;
        }
        Date& operator+(int i){
            static Date dt;
            dt.day = this->day + i;
            return dt;
        }
        Date& operator-(int i){
            static Date dt;
            dt.day = this->day - i;
            return dt;
        }
        Date operator-(Date d){
            Date dnew;
            dnew.day = this->day - d.day;
            dnew.month = this->month - d.month;
            dnew.year = this->year - d.year;
            return dnew;
        }
        Date operator++(){
            this->day++;
            return *this;
        }
        Date operator++(int){
            Date result(*this);
            ++this->day;
            return result;
        }
        Date operator--(){
            this->day--;
            return *this;
        }
        Date operator--(int){
            Date result(*this);
            --this->day;
            return result;
        }
};

int main()
{
    Date d1(10, 12, 22);
    Date d2(14, 5, 20);
    Date d3;
    cout<<"Date1: ";
    d1.Write();
    cout<<"Date2: ";
    d2.Write();
    
    d3 = d1 + 5;
    cout<<"Date3: ";
    d3.Write();
    d3 = d1-5;
    cout<<"Date3: ";
    d3.Write();
    d3 = d1-d2;
    cout<<"Date3: ";
    d3.Write();
    
    d3 = d1++;
    cout<<"Date1: ";
    d1.Write();
    cout<<"Date3: ";
    d3.Write();
    
    ++d1;
    cout<<"Date1: ";
    d1.Write();

    return 0;
}
