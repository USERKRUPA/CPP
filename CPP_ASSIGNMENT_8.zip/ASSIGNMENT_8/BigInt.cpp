/*
 In BigInt class overload following operators:
   Binary operators + - * / to work with
   - both operands of type BigInt
   - one BigInt operand and one int
   Unary operators ++ and -- in both pre and post form.
   Also write a small program to demonstrate the use of BigInt class and overloaded operators.
*/
#include<iostream>
using namespace std;
class BigInt{
    int num;
    public: 
        BigInt():num(0){
        }
        BigInt(int num): num(num){
        }
        BigInt(BigInt &b){
            this->num = b.num;
        }
        void display() const{
            cout << num << endl;
        }
        void set(){
            cout << "Enter number: ";
            cin >> num;
        }
        bool operator== (BigInt b){
            if(b.num == this->num)
                return true;
            return false;
        }
        bool operator==(int no){
            if(this->num == no)
                return true;
            return false;
        }
        bool operator<=(BigInt b){
            if(this->num <= b.num)
                return true;
            return false;
        }
        bool operator>(BigInt b){
            if(*this <= b)
                return false;
            return true;
        }
        bool operator>=(BigInt b){
            if(this->num >= b.num)
                return true;
            return false;
        }
        bool operator<(BigInt b){
            if(*this >= b)
                return false;
            return true;
        }
        bool operator!=(BigInt b){
            if(*this == b)
                return false;
            return true;
        }
        BigInt operator+(BigInt b){
            BigInt ans;
            ans.num = b.num + this->num;
            return ans;
        }
        BigInt& operator+(int data){
            static BigInt ans;
            ans.num = this->num + data;
            return ans;
        }
        
        BigInt operator-(BigInt b){
            BigInt ans;
            ans.num = this->num - b.num;
            return ans;
        }
        BigInt& operator-(int data){
            static BigInt ans;
            ans.num = this->num - data;
            return ans;
        }
        BigInt operator*(BigInt b){
            BigInt ans;
            ans.num = this->num * b.num;
            return ans;
        }
        BigInt& operator*(int data){
            static BigInt ans;
            ans.num = this->num * data;
            return ans;
        }
        BigInt operator/(BigInt b){
            BigInt ans;
            ans.num = this->num / b.num;
            return ans;
        }
        BigInt& operator/(int data){
            static BigInt ans;
            ans.num = this->num / data;
            return ans;
        }
        BigInt operator++(){
            this->num++;
            return *this;
        }
        BigInt operator++(int){
            BigInt bt(*this);
            this->num++;
            return bt;
        }
        BigInt operator--(){
            this->num--;
            return *this;
        }
        BigInt operator--(int){
            BigInt bt(*this);
            this->num--;
            return bt;
        }
};
bool operator==(int no, BigInt b){
    return (b == no);
}
BigInt operator+(int data, BigInt b){
    BigInt ans = b + data;
    return ans;
}
BigInt operator-(int data, BigInt b){
    BigInt ans = b - data;
    return ans;
}
BigInt operator*(int data, BigInt b){
    BigInt ans = b * data;
    return ans;
}
BigInt operator/(int data, BigInt b){
    BigInt ans = b/data;
    return ans;
}
int main(){
    BigInt b1, b2(2), b3(b2);
    b1.set();

    if(b2 == b3)
        cout << "b2 and b3 are Equal"<<endl;
    else
        cout << "b2 and b3 are not equal"<<endl;
    if(b2 == 5)
        cout << "b2 and 5 are Equal"<<endl;
    else
        cout << "b2 and 5 are not equal"<<endl;
    if(5 == b2)
        cout << "b2 and 5 are Equal"<<endl;
    else
        cout << "b2 and 5 are not equal"<<endl;
    if(b1 >= b3)
        cout << "b1 is greater than b3"<<endl;
    else
        cout << "b1 is not greater than b3"<<endl;
    b3 = b1 / b2;
    b3.display();
    b3 = b1 + 5;
    b3.display();
    b3 = b1 - 5;
    b3.display();
    int i = 5;
    b3 = b1 * i;
    b3.display();
    b3 = i * b1; //operator *(i, b1);
    b3.display();
    b3 = ++b2;
    b3.display();
    return 0;
}