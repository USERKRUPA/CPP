/*
In String class, implement following:
   - Copy constructor to perform deep copy.
   - Overload assignment operator, to perform deep copy.
*/
#include<iostream>
#include<cstring>
using namespace std;

class String{
	private:
		char *arr;
		int size;
	public :
		String():size(6){	
            arr = new char[size];
			arr[0] = '\0';
		}
		String(char *str){   
            size = strlen(str);
			arr = new char[size + 1];
			strcpy(arr, str);
		}
		String(String &obj){ 
            cout<<"Copy Constructor Called"<<endl;
            size = obj.size;
			arr = new char[size];
			strcpy(arr, obj.arr);
		}	
		String& operator=(String &obj){  
            cout<<"Assignment Operator Function Called"<<endl;
			delete[] arr;
            size = obj.size;
			arr = new char[size];
			strcpy(arr, obj.arr);
			return *this;
		}
		~String(){
    		cout<<"memory is freed "<<endl;
			delete[] arr;
		}
		void display(){   
            for(int i = 0; arr[i] != '\0'; i++){
				cout<<arr[i];
			}
			cout<<endl;
		}
};
int main(){
	String s1("krupa thumar");
	cout<<"String1 is: ";
    s1.display();

	String s2(s1);
	cout<<"String2 is: ";
	s2.display();

	String s3;
	cout<<"String3 is :- ";
	s3.display();
	s3 = s1;
	cout<<"String3 is :-  ";
	s3.display();
    return 0;
}
