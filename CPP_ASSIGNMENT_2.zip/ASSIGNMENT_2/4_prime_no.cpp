#include<iostream>
using namespace std;
int main(void){
    int strt, end, n, i;
    do{
        cout<<"Enter starting positive no: ";
        cin>>strt;
    }while(strt < 0);
    do{
        cout<<"Enter last positive no: ";
        cin>>end;
    }while(end < 0);
    n = strt; 
    while(n <= end){
        for(i = 2; i < n; i++){
            if(n % i == 0){
                break;
            }
        }
        if(i == n){
            cout<<n<<",";
        }
        n++;
    }
    return 0;
}