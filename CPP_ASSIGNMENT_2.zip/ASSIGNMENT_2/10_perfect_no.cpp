#include <iostream>
using namespace std;
int main() {
    int num, sum = 0;
    do{
        cout<<"enter a positive number: ";
        cin>>num;
    }while(num < 0);
    for(int i = 1; i < num; i++){
        if(num % i == 0)
            sum = sum + i; //sum of factors
    }
    if(sum == num)
        cout<<"perfect no";
    else
        cout<<"not perfect";
    return 0;
}