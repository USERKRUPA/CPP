#include <iostream>
using namespace std;
int main() {
    int num, fact, i, result;
    do{
        cout<< "enter a positive number: ";
        cin>> num;
    }while(num < 0);
    for(i = 1; i <= num; i++){
        result = num % i;
        if(result == 0){
            cout<<i<<",";
        }
    }
    return 0;
}