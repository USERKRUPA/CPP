#include <iostream>
using namespace std;
int main() {
    int num, i, result = 0;
    do{
        cout<<"enter a positive number: ";
        cin>>num;
    }while(num < 0);
    while(num > 0){
       int rem = num % 10;
        result =  result + rem; 
        num = num / 10;
    }
    cout<<result;
    
    return 0;
}