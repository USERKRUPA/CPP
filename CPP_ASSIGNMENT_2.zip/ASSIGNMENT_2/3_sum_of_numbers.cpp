#include<iostream>
using namespace std;
int main(){
    int n, m, sum = 0;
    do{
        cout<<"Enter starting positive integer: ";
        cin>>n;
    }while(n < 0);
    
    do{
        cout<<"Enter last positive integer: ";
        cin>>m;
    }while(m < 0);

    for(int i = n; i <= m; i++){
        sum = sum + i;
    }
    cout<<"sum of numbers between "<<n<<" and "<<m<<" is: "<<sum<<endl;
    return 0;
}